// Make nav respond to scrolling: add/remove .nav-scrolled for visual changes
(function () {
  const nav = document.querySelector('.main-nav');
  if (!nav) return;

  let ticking = false;

  function onScroll() {
    const scrolled = window.scrollY > 8;
    if (scrolled) nav.classList.add('nav-scrolled');
    else nav.classList.remove('nav-scrolled');
    ticking = false;
  }

  window.addEventListener('scroll', function () {
    if (!ticking) {
      window.requestAnimationFrame(onScroll);
      ticking = true;
    }
  }, { passive: true });

  // Run once to set initial state (for pages loaded scrolled or when using anchors)
  onScroll();
})();
